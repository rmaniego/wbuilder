# wBuilder
```
    wBuilder
    (c) 2020 Rodney Maniego Jr.
    MIT License
```

HTML template generator module for Python.

*Requirements:*
- BS4

Go to `examples/pagebuilder.py` for basic usage.
Returned value is in string and can be saved into file.

*Features*
1. Integrate element shortcuts as WebBuilder method instead as a separate ElemBuilder.
2. In-house save to file.
